package com.itheima.service;

import com.itheima.mapper.UserMapper;
import com.itheima.pojo.Users;
import com.itheima.util.SqlSessionFactoryUtil;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;

public class UserService {
    SqlSessionFactory factory = SqlSessionFactoryUtil.getSessionFactory();

    /**
     * 查询所有
     *
     * @return
     */
    public Users select(String card_id, String password) {


        //2. 获取SqlSession
        SqlSession sqlSession = factory.openSession();
        //3. 获取UserMapper
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);

        //4. 调用方法
        Users users = mapper.select(card_id, password);

        sqlSession.close();

        return users;
    }

    /**
     * 注册
     *
     */
    public void insert(Users user) {

        //2. 获取SqlSession
        SqlSession sqlSession = factory.openSession();
        //3. 获取BrandMapper
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);

        //4. 调用方法
        mapper.insert(user);

        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
    }

    public Users login(String card_id, String password) {
        SqlSession sqlSession = factory.openSession();
        //3. 获取BrandMapper
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);

        //4. 调用方法
        Users users = mapper.select(card_id, password);
        //释放资源
        sqlSession.close();
        return users;
    }

    /**
     * 取款
     */
    public void withdraw(String card_id, int sum) {

        //2. 获取SqlSession
        SqlSession sqlSession = factory.openSession();
        //3. 获取BrandMapper
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);

        //4. 调用方法
        mapper.withdraw(card_id, sum);

        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
    }

    /**
     * 存款
     */
    public void deposit(String card_id, int sum) {

        //2. 获取SqlSession
        SqlSession sqlSession = factory.openSession();
        //3. 获取BrandMapper
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);

        //4. 调用方法
        mapper.deposit(card_id, sum);

        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
    }

    /**
     * 查询余额
     *
     * @return
     */
    public int selectFunds(String card_id) {


        //2. 获取SqlSession
        SqlSession sqlSession = factory.openSession();
        //3. 获取UserMapper
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);

        //4. 调用方法
        int funds = mapper.selectFunds(card_id);

        sqlSession.close();

        return funds;
    }

    public Users selectByCard_id(String card_id){
        SqlSession sqlSession = factory.openSession();

        UserMapper mapper = sqlSession.getMapper(UserMapper.class);

        Users user = mapper.selectByCard_id(card_id);

        sqlSession.close();


        return user;

    }
    /**
     *  修改密码
     *
     * @return
     */
    public void alter(String card_id,String password){
        SqlSession sqlSession = factory.openSession();

        UserMapper mapper = sqlSession.getMapper(UserMapper.class);

        mapper.alter(card_id,password);
        sqlSession.commit();
        sqlSession.close();
        //提交事务
    }
    /**
     *  注销账户
     *
     * @return
     */
    public void drop(String card_id){
        SqlSession sqlSession = factory.openSession();

        UserMapper mapper = sqlSession.getMapper(UserMapper.class);

        mapper.drop(card_id);
        sqlSession.commit();
        sqlSession.close();
        //提交事务
    }

}
