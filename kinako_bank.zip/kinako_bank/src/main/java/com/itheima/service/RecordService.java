package com.itheima.service;

import com.itheima.mapper.RecordMapper;
import com.itheima.pojo.Records;
import com.itheima.util.SqlSessionFactoryUtil;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;

public class RecordService {
    SqlSessionFactory factory = SqlSessionFactoryUtil.getSessionFactory();

    /**
     * 查询所有
     *
     * @return
     */
    public List<Records> selectAll() {
        //调用BrandMapper.selectAll()

        //2. 获取SqlSession
        SqlSession sqlSession = factory.openSession();
        //3. 获取BrandMapper
        RecordMapper mapper = sqlSession.getMapper(RecordMapper.class);

        //4. 调用方法
        List<Records> records = mapper.selectAll();

        sqlSession.close();

        return records;
    }

    /**
     * 查询所有
     *
     * @return
     */
    public List<Records> select(String card_id) {
        //调用BrandMapper.selectAll()

        //2. 获取SqlSession
        SqlSession sqlSession = factory.openSession();
        //3. 获取BrandMapper
        RecordMapper mapper = sqlSession.getMapper(RecordMapper.class);

        //4. 调用方法
        List<Records> records = mapper.select(card_id);

        sqlSession.close();

        return records;
    }
    /**
     * 取款

     */
    public void withdraw(String card_id, int sum) {
        //2. 获取SqlSession对象
        SqlSession sqlSession = factory.openSession();
        //3. 获取BrandMapper
        RecordMapper mapper = sqlSession.getMapper(RecordMapper.class);

        //4. 调用方法
        mapper.withdraw(card_id, sum);
        sqlSession.commit();//提交事务

        //5. 释放资源
        sqlSession.close();
    }

    /**
     * 存款

     */
    public void deposit(String card_id, int sum) {
        //2. 获取SqlSession对象
        SqlSession sqlSession = factory.openSession();
        //3. 获取BrandMapper
        RecordMapper mapper = sqlSession.getMapper(RecordMapper.class);

        //4. 调用方法
        mapper.deposit(card_id ,sum);
        sqlSession.commit();//提交事务

        //5. 释放资源
        sqlSession.close();
    }
}