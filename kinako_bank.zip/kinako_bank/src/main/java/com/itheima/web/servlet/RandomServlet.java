package com.itheima.web.servlet;

import com.itheima.pojo.Users;
import com.itheima.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Random;

@WebServlet("/randomServlet")
public class RandomServlet extends HttpServlet {

    private UserService userService = new UserService();
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //1. 生成随机八位数卡号
        StringBuilder str = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 8; i++) {
            str.append(random.nextInt(10));
        }
        //int num = Integer.parseInt(str.toString());

        //确定不会重复
        Users user = userService.selectByCard_id(str.toString());

        if (user != null){
            request.getRequestDispatcher("/kinako_bank/randomServlet").forward(request,response);
        }else {
            //System.out.println(num);
            //request.setAttribute("random",num);

            //登录页面不显示卡号，注册成功后跳转页面显示注册成功的卡号和密码，并有一个返回登录按钮
            System.out.println(str.toString());
            request.setAttribute("random",str.toString());


            request.getRequestDispatcher("/register.jsp").forward(request,response);
        }


    }
}
