package com.itheima.web.servlet;

import com.itheima.pojo.Users;
import com.itheima.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

import static sun.misc.VM.getState;

@WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet{
    private UserService service = new UserService();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 接收用户数据
        String card_id = req.getParameter("card_id");
        String password = req.getParameter("password");
        Users user=service.login(card_id,password);


        if(user != null && user.getState() !=null) {
            int fund = service.selectFunds(card_id);
            String username = user.getUsername();
            String funds = Integer.toString(fund);
            System.out.println(fund);
            HttpSession session= req.getSession();
            session.setAttribute("card_id",card_id);
            session.setAttribute("funds",funds);
            session.setAttribute("username",username);
            req.setAttribute("card_id",card_id);
            req.setAttribute("funds",funds);
            req.setAttribute("username",username);
            req.getRequestDispatcher("/record.jsp").forward(req,resp);

        } else {
            if(user != null && user.getState() ==null) {
                req.setAttribute("login_msg", "账号已注销");
                req.getRequestDispatcher("/login.jsp").forward(req, resp);
            }else {
                req.setAttribute("login_msg", "用户名或者密码错误");
                req.getRequestDispatcher("/login.jsp").forward(req, resp);
            }
        }

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req,resp);
    }
}
