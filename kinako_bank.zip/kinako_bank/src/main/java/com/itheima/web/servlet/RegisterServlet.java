package com.itheima.web.servlet;

import com.itheima.pojo.Users;
import com.itheima.service.UserService;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/registerServlet")
public class RegisterServlet extends HttpServlet {

    UserService userService = new UserService();
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //处理POST请求的乱码问题
        request.setCharacterEncoding("utf-8");


        //接收数据
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String card_id = request.getParameter("card_id");
        String funds = request.getParameter("funds");

        Users user = new Users();
        user.setCard_id(card_id);
        user.setUsername(username);
        user.setPassword(password);
        user.setFunds(Integer.parseInt(funds));
        user.setState("1");


        //执行方法
        userService.insert(user);

        request.setAttribute("user",user);
        request.getRequestDispatcher("/confirm.jsp").forward(request,response);



    }
}
