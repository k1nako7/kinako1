package com.itheima.web.servlet;

import com.itheima.service.RecordService;
import com.itheima.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.IOException;
@WebServlet("/depServlet")
public class DepServlet extends HttpServlet{
    private RecordService recordService = new RecordService();
    private UserService userService = new UserService();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       // String dep = request.getParameter("sum");

        BufferedReader br = request.getReader();
         String dep = br.readLine();
        System.out.println(dep);
        int sum = Integer.parseInt(dep);

        HttpSession session = request.getSession();
        String card_id = (String)session.getAttribute("card_id");
        System.out.println(card_id);
        //2. 调用service添加
        recordService.deposit(card_id,sum);
        userService.deposit(card_id,sum);
        //3. 响应成功的标识
        response.getWriter().write("success");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

}
