package com.itheima.web.servlet;

import com.itheima.service.RecordService;
import com.itheima.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.IOException;
@WebServlet("/witServlet")
public class WitServlet extends HttpServlet{
    private RecordService recordService = new RecordService();
    private UserService userService = new UserService();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


        BufferedReader br = request.getReader();
        String wit = br.readLine();
        System.out.println(wit);

        int sum = Integer.parseInt(wit);
        HttpSession session = request.getSession();
        String card_id = (String)session.getAttribute("card_id");
        String fund = (String)session.getAttribute("funds");
        System.out.println(fund);
        int funds = Integer.parseInt(fund);
        if(funds>sum) {//2. 调用service添加
            recordService.withdraw(card_id, sum);
            userService.withdraw(card_id, sum);
            //3. 响应成功的标识
            response.getWriter().write("success");
        }else{
            response.getWriter().write("fair");
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

}