package com.itheima.pojo;

public class Records {
    private String card_id;
    private int    sum;
    private String time;
    private String operate;


    public String getCard_id() {
        return card_id;
    }


    public int getSum() {
        return sum;
    }

    public String getTime() {
        return time;
    }

    public String getOperate() {
        return operate;
    }

    public void setCard_id(String card_id) {
        this.card_id = card_id;
    }


    public void setOperate(String operate) {
        this.operate = operate;
    }

    public void setSum(int sum) {
        this.sum = sum;
    }

    public void setTime(String time) {
        this.time = time;
    }
    @Override
    public String toString() {
        return "Users{" +
                "card_id= " + card_id + '\'' +
                "sum= " + sum + '\'' +
                "time=   " + time + '\'' +
                "operate=" + operate + '\'' +
                '}';
    }
}