package com.itheima.pojo;

public class Users {
    private String card_id;
    private int funds;
    private String state;
    private String username;
    private String password;

    public String getCard_id() {
        return card_id;
    }

    public void setCard_id(String card_id) {
        this.card_id = card_id;
    }

    public int getFunds() {
        return funds;
    }

    public void setFunds(int funds) {
        this.funds = funds;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "Users{" +
                "card_id=" + card_id +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", funds=" + funds + '\''+
                ", state" + state + '\'' +
                '}';
    }
}
