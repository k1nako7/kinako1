package com.itheima.mapper;

import com.itheima.pojo.Users;
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface UserMapper {
    /**
     * 根据用户名和密码查询用户对象
     * @param card_id
     * @param password
     * @return
     */

    @Select("select * from users where card_id=#{card_id} and password=#{password}")
    Users select(@Param("card_id") String card_id, @Param("password") String password);

    /**
     * 注册要用的验证卡号
     * @param card_id
     * @return
     */
    @Select("select * from users where card_id = #{card_id} ")
    Users selectByCard_id(String card_id);

    /**
     * 查询余额
     * @param card_id
     * @return
     */
    @Select("select funds from users where card_id = #{card_id} ")
    int selectFunds(String card_id);



    /**
     * 注册

     * @return
     */
    @Insert("insert into users values (#{card_id},#{password},#{username},#{funds},#{state})")
    void insert(Users user);
    /**
     *
     * @param card_id
     * @param password
     * @return
     */
    @Update("update users set password =#{password} where card_id=#{card_id}")
    void alter(@Param("card_id") String card_id, @Param("password") String password);
    /**
     * 取款
     * @param card_id
     * @param sum
     * @return
     */
    @Update("update users set funds = funds-#{sum} where card_id=#{card_id} ")
    void withdraw(@Param("card_id") String card_id,@Param("sum") int sum);
    /**
     * 存款
     * @param card_id
     * @param sum
     * @return
     */
    @Update("update users set funds = funds+#{sum} where card_id=#{card_id} ")
    void deposit(@Param("card_id") String card_id,@Param("sum") int sum);
    /**
     * @param card_id
     * @return
     */
    @Update("update users set state = null ,funds = 0 where card_id=#{card_id} ")
    void drop(@Param("card_id") String card_id);

}
