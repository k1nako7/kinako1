package com.itheima.mapper;

import com.itheima.pojo.Records;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface RecordMapper {

    /**
     * 查询所有
     * @return
     */
    @Select("select * from records")
    List<Records> selectAll();

    /**
     * 查询所有
     * @Param card_id
     * @return
     */
    @Select("select * from records where card_id= #{card_id}")
    List<Records> select(String card_id);
    /**
     * 存钱
     * @param  card_id
     * @param sum
     * @return
     */
    @Insert("insert into records values(#{card_id},#{sum},now(),'deposit')")
    void deposit(@Param("card_id") String card_id,@Param("sum") int sum);
    /**
     * 存钱
     * @param card_id
     * @param sum
     * @return
     */
    @Insert("insert into records values(#{card_id},#{sum},now(),'withdraw')")
    void withdraw(@Param("card_id") String card_id,@Param("sum") int sum);
}
